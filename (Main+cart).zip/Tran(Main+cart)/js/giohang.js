function updateTotalPrice() {
    // Get the quantity and price elements based on their IDs
    var quantity1 = parseInt(document.getElementById('quantity1').textContent);
    var price1 = parseInt(document.getElementById('price1').textContent);

    var quantity2 = parseInt(document.getElementById('quantity2').textContent);
    var price2 = parseInt(document.getElementById('price2').textContent);

    // Calculate total price
    var totalPrice = (quantity1 * price1) + (quantity2 * price2);

    // Update the "Tổng" span with the calculated total price
    document.querySelector('.total-price').textContent = totalPrice.toLocaleString('vi-VN') + ' VND';
}

// Call the function when the page loads

window.onload = function () {
    // Call the updateTotalPrice function
    updateTotalPrice();
};



